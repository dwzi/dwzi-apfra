<?php

$datafile_perpage = 10;

$datafile_path = DEF_PATH_PRIVATE."doc";
$datafile_search = "*";

?>
